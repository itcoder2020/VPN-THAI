#!/bin/bash
# Created by Kang Wahid
# Dilarang Keras Mengambil/mencuplik/mengcopy sebagian atau seluruh script ini.
# Hak Cipta Kang Wahid (Dilindungi Undang-Undang nomor 19 Tahun 2002)
curl Kang Wahid/index.html
echo ""